package fun.wlfj.NodeFramework.Edge;

import fun.wlfj.NodeFramework.NodeStyle.Node;

public class NormalEdge implements Edge {
	
	private Node point1, point2;
	private double distance;

	/**
	 * ע�⣡�����Ǳ�����ǵ���ߣ����Ҫ����˫����봴�����Σ�
	 * @param point1 ��ʼ��
	 * @param point2 ������
	 */
	public NormalEdge(Node point1, Node point2) {
		super();
		this.point1 = point1;
		this.point2 = point2;
		distance = Math.pow(point1.getX() - point2.getX(), 2) + Math.pow(point1.getY() - point2.getY(), 2);
	}

	@Override
	public double getDistance() {
		// TODO Auto-generated method stub
		return distance;
	}

	@Override
	public Node getNodeA() {
		// TODO Auto-generated method stub
		return point1;
	}

	@Override
	public Node getNodeB() {
		// TODO Auto-generated method stub
		return point2;
	}
	
	@Override
	public String toString() {
		// TODO Auto-generated method stub
		return point1.getX() + " " + point1.getY();
	}

}
