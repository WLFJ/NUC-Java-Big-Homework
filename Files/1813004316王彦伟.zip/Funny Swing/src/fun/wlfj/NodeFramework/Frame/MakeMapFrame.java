package fun.wlfj.NodeFramework.Frame;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;

import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JDialog;
import javax.swing.JPanel;

import fun.wlfj.NodeFramework.Helper.SerializeHelper;
import fun.wlfj.NodeFramework.NodeStyle.Node;
import fun.wlfj.NodeFramework.Widget.NodeInfoPanel;

public class MakeMapFrame extends BaseMapFrame {

	public MakeMapFrame() throws IOException {
		super();
		setTitle("��ͼ�༭ʵ�ù���-0.2 By WLFJ");
	}

	boolean isDelete = false;

	public JPanel designToolBar() {
		// ��ƹ�����
		JPanel toolsPanel = new JPanel();
		JButton btn_loadProject = new JButton("���빤��");
		JButton btn_loadImage = new JButton("����ͼƬ");
		JCheckBox cb_deleteEdge = new JCheckBox("ɾ��ģʽ");
		JButton btn_saveProject = new JButton("���湤��");
		JCheckBox cb_disableEdge = new JCheckBox("��ֹ�ı�");
		JCheckBox cb_doubleEdge = new JCheckBox("����˫��");
		toolsPanel.add(btn_loadProject);
		toolsPanel.add(btn_loadImage);
		toolsPanel.add(cb_deleteEdge);
		toolsPanel.add(btn_saveProject);
		toolsPanel.add(cb_disableEdge);
		toolsPanel.add(cb_doubleEdge);

		btn_saveProject.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				SerializeHelper helper = new SerializeHelper(null, null, nodePanel.getPoints());
				try {
					ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream(new File("data.mi")));
					oos.writeObject(helper);
					oos.close();
				} catch (FileNotFoundException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				} catch (IOException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
			}
		});
		// ������Ϣ
		btn_loadProject.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				// �������ǵõ�ҪҪ�����λ�� ������Ϊʱ���ϵ��д�ˣ�
				try {
					ObjectInputStream ois = new ObjectInputStream(new FileInputStream(new File("data.mi")));
					SerializeHelper helper = (SerializeHelper) ois.readObject();
					nodePanel.setPoints(helper.getPoints());
					nodePanel.init();
					ois.close();
				} catch (FileNotFoundException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				} catch (IOException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				} catch (ClassNotFoundException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
			}
		});
		// ����ͼƬ
		btn_loadImage.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				try {
					nodePanel.setImage("map.png");
				} catch (IOException e1) {
					// TODO: handle exception
				}
				nodePanel.repaint();
			}
		});

		cb_deleteEdge.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				nodePanel.setDelete(cb_deleteEdge.isSelected());
			}
		});
		// ����˫���༭�ڵ���Ϣ
		nodePanel.addMouseListener(new MouseAdapter() {

			@Override
			public void mouseClicked(MouseEvent e) {
				super.mouseClicked(e);
				if (e.getButton() == MouseEvent.BUTTON1 && e.getClickCount() == 2) {
					// ��������Ҫ����һ���Ի���
					Node t = nodePanel.getCurActivedPoint(e.getX(), e.getY());
					JDialog dialog = new JDialog();
					NodeInfoPanel panel = new NodeInfoPanel(t.getProvider(), dialog);
					dialog.add(panel);
					dialog.pack();
					dialog.setVisible(true);
				}
			}

		});

		cb_disableEdge.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				nodePanel.setReadOnly(cb_disableEdge.isSelected());
			}
		});

		cb_doubleEdge.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				nodePanel.setDouble(cb_doubleEdge.isSelected());
			}
		});

		return toolsPanel;
	}
}
