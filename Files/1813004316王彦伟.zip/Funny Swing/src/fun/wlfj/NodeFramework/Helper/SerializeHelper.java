package fun.wlfj.NodeFramework.Helper;

import java.io.Serializable;
import java.util.List;

import fun.wlfj.NodeFramework.NodeStyle.Node;

/**
 * ���ڰ������ǽ���Ҫ�������Ϣ��������
 * @author lazyWind
 *
 */
public class SerializeHelper implements Serializable {
	private Node startNode, endNode;
	private List<Node> points;
	public SerializeHelper(Node startNode, Node endNode, List<Node> points) {
		super();
		this.startNode = startNode;
		this.endNode = endNode;
		this.points = points;
	}
	public Node getStartNode() {
		return startNode;
	}
	public Node getEndNode() {
		return endNode;
	}
	public List<Node> getPoints() {
		return points;
	}
	
}
