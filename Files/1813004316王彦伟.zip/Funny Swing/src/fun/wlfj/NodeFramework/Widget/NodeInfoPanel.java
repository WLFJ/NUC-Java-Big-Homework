package fun.wlfj.NodeFramework.Widget;

import java.awt.Component;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextArea;
import javax.swing.JTextField;

import fun.wlfj.NodeFramework.Helper.NodeInfoProvider;

/**
 * һ������չʾ��Ϣ��panel��
 * 
 * @author lazyWind
 *
 */
public class NodeInfoPanel extends JPanel implements ActionListener {

	/**
	 * 
	 */
	private static final long serialVersionUID = -2868760410513944185L;

	private NodeInfoProvider infoProvider;
	
	private JDialog context;

	JTextField tf_name;
	JTextArea ta_description;

	public NodeInfoPanel(NodeInfoProvider infoProvider, JDialog context) {
		// �ڴ��巵�ص�ʱ�����ǻ���õ�����ϢӦ����ô���أ������ٷ���һ���µ�Provider
		this.infoProvider = infoProvider;
		this.context = context;
		JLabel lb_name = new JLabel("���ƣ�");
		tf_name = new JTextField(infoProvider.getName());
		JLabel lb_description = new JLabel("������");
		ta_description = new JTextArea(infoProvider.getDescription());
		JButton btn_ok = new JButton("ȷ��");
		JButton btn_cancel = new JButton("ȡ��");
		setLayout(new GridLayout(3, 2));
		add(lb_name);
		add(tf_name);
		add(lb_description);
		add(ta_description);
		add(btn_ok);
		add(btn_cancel);

		btn_ok.addActionListener(this);
		
		btn_cancel.addActionListener(e->{
			context.dispose();
		});

	}

	public NodeInfoProvider getInfoProvider() {
		return infoProvider;
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		infoProvider.setDescription(ta_description.getText());
		infoProvider.setName(tf_name.getText());
		System.out.println(ta_description.getText());
		context.dispose();
	}

}
