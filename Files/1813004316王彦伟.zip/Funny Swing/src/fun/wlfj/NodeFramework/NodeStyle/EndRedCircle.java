package fun.wlfj.NodeFramework.NodeStyle;

import java.awt.Color;
import java.awt.Graphics;

public class EndRedCircle extends AbstractCircle {
	
	public EndRedCircle(int x, int y) {
		super(x, y);
		setColor(Color.yellow);
		// TODO Auto-generated constructor stub
	}
	
	public EndRedCircle() {
		// TODO Auto-generated constructor stub
		this(0, 0);
	}

	@Override
	public void paintNode(Graphics g) {
		super.paintNode(g);
		//���м仭���ְɣ�
		g.setColor(Color.BLACK);
		g.drawString("E", getX() + Cir_W/2, getY() + Cir_H/2);
	}
	
}
