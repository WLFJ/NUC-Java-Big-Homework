package fun.wlfj.NodeFramework.NodeStyle;

/**
 * һ���ɰ���Բ��!ͬʱ�м仹֧��ֱ�����ӣ�
 * @author lazyWind
 *
 */
public class RedCircle extends AbstractCircle {

	/**
	 * 
	 */
	private static final long serialVersionUID = -3131394916740577488L;
	

	public RedCircle(int x, int y) {
		super(x, y);
		// TODO Auto-generated constructor stub
	}
	
	public RedCircle() {
		// TODO Auto-generated constructor stub
		super();
	}
	
}
