package fun.wlfj.NodeFramework.NodeStyle;
import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.util.List;
import java.util.Vector;

import fun.wlfj.NodeFramework.Helper.NodeGroup;
import fun.wlfj.NodeFramework.Helper.NodeInfoProvider;

public abstract class AbstractCircle implements Node, Cloneable {

	/**
	 * 
	 */
	private static final long serialVersionUID = -8606028463880376729L;

	public static final int Cir_W = 20, Cir_H = 20;
	
	private int x, y;
	private Color color = Color.red;
	
	private List<Node> relatedToList = new Vector<Node>();
	
	private NodeGroup group;
	private boolean isSelected = false;
	
	NodeInfoProvider info = new NodeInfoProvider("", "");
	
	/**
	 * �ὫԲ�����������֮λ�á�������֮Բ��������ƫ�Ƶ�
	 * @param x
	 * @param y
	 */
	public AbstractCircle(int x, int y) {
		this.x = x - Cir_W / 2;
		this.y = y - Cir_H / 2;
	}
	
	public AbstractCircle() {
		// TODO Auto-generated constructor stub
	}
	
	@Override
	public boolean accepted(int x, int y) {
		//���ڵļ�������е����Ⱑ
		//System.out.println(x + " " + y + " " + this.x + " " + this.y);
		double centerX = this.x + Cir_W/2, centerY = this.y + Cir_W/2;
		return Math.pow(centerX - x, 2) + Math.pow(centerY - y, 2) <= (Cir_H / 2) * (Cir_H / 2);
	}
	
	@Override
	public void paintNode(Graphics g) {
		Graphics2D g2d = (Graphics2D) g;
		g2d.setColor(color);
		g2d.fillOval(x, y, Cir_W, Cir_H);
		g2d.setColor(Color.black);
		paintLine(g2d);
	}
	
	public void paintLine(Graphics g) {
		Graphics2D g2d = (Graphics2D) g;
		g2d.setColor(isSelected ? Color.blue : Color.black);
		g2d.setStroke(new BasicStroke(2.5f));
		for (Node p : relatedToList) {
			//����������ˣ�
			if(p.isSelected() == false || (p.isSelected() && p.getPoints().contains(this) == false)) {
				g.drawLine(this.x + Cir_W / 2, this.y + Cir_W / 2, p.getX() + Cir_H / 2, p.getY() + Cir_W / 2);
			}
		}
	}
	

	@Override
	public void addNode(Node p) {
		if (relatedToList.contains(p) || p.equals(this) )//�Ѿ����˾Ͳ�Ҫ�����ˣ�ͬʱ��Ҫ���Ի���
			return;
		relatedToList.add(p);
	}

	@Override
	public boolean removeLine(Node p) {
		if(p == null) return false;
		relatedToList.remove(p);
		p.getPoints().remove(this);
		return true;
	}

	@Override
	public void addNodeGroup(NodeGroup group) {
		this.group = group;
	}

	@Override
	public void setSelected(boolean selected) {
		this.color = selected ? Color.green : Color.red;
		isSelected = selected;
	}

	@Override
	public boolean isSelected() {
		// TODO Auto-generated method stub
		return isSelected;
	}


	@Override
	public int getX() {
		return x;
	}


	@Override
	public int getY() {
		return y;
	}



	public Color getColor() {
		return color;
	}


	@Override
	public NodeGroup getGroup() {
		return group;
	}


	@Override
	public void setX(int x) {
		//x -= RedCircle.Cir_W / 2;
		this.x = x;
	}


	@Override
	public void setY(int y) {
		//y -= RedCircle.Cir_H / 2;
		this.y = y;
	}



	public void setColor(Color color) {
		this.color = color;
	}



	public void setGroup(NodeGroup group) {
		this.group = group;
	}


	@Override
	public List<Node> getPoints() {
		// TODO Auto-generated method stub
		return relatedToList;
	}
	
	public void setInfo(NodeInfoProvider info) {
		this.info = info;
	}
	
	public NodeInfoProvider getInfo() {
		return info;
	}

	@Override
	public NodeInfoProvider getProvider() {
		// TODO Auto-generated method stub
		return info;
	}

	@Override
	public void setProvider(NodeInfoProvider provider) {
		// TODO Auto-generated method stub
		this.info = provider;
	}
	
	@Override
	public Object clone() throws CloneNotSupportedException {
		// TODO Auto-generated method stub
		return super.clone();//ֻ����������
	}
	
	@Override
	public boolean equals(Object obj) {
		if(obj instanceof Node) {
			Node node = (Node) obj;
			return this.x == node.getX() && this.y == node.getY();
		}
		return false;
	}
	
	/**
	 * �û��������ݽṹʹ��
	 */
	@Override
	public int hashCode() {
		return x * 499 + y * 503;
	}

}
