package fun.wlfj.NodeFramework.NodeStyle;

import java.awt.Color;
import java.awt.Graphics;

public class StartRedCircle extends AbstractCircle {

	public StartRedCircle(int x, int y) {
		super(x, y);
		setColor(Color.yellow);
		// TODO Auto-generated constructor stub
	}
	
	public StartRedCircle() {
		// TODO Auto-generated constructor stub
		this(0, 0);
	}
	
	//Ϊʲô�ڻ��Ƶ�ʱ��ᷢ��ƫ�ư���
	@Override
	public void paintNode(Graphics g) {
		super.paintNode(g);
		//����һ�����ְɣ�
		g.setColor(Color.BLACK);
		g.drawString("S", getX() + Cir_W/2, getY() + Cir_H/2);
	}
	
}
