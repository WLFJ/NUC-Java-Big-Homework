package fun.wlfj.NodeFramework.Test;

import java.io.IOException;

import javax.swing.JFrame;

import fun.wlfj.NodeFramework.Frame.SolvePathFrame;

public class TestSolveSinglePath {
	public static void main(String[] args) throws IOException {
		JFrame frame = new SolvePathFrame();
		frame.setVisible(true);
	}
}
