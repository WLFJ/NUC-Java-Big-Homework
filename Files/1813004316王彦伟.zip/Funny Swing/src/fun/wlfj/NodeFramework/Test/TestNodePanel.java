package fun.wlfj.NodeFramework.Test;

import java.io.IOException;

import javax.swing.JFrame;

import fun.wlfj.NodeFramework.Widget.NodePanel;

public class TestNodePanel {

	public static void main(String[] args) throws IOException {
		JFrame frame = new JFrame();
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		NodePanel panel = new NodePanel();
		panel.setImage("map.jpg");
		frame.add(panel);
		frame.pack();
		frame.setVisible(true);
		
	}

}
