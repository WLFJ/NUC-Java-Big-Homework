package fun.wlfj.NodeFramework.Test;

import java.io.IOException;

import javax.swing.JFrame;

import fun.wlfj.NodeFramework.Frame.MakeMapFrame;

public class TestMakeMapFrame {
	public static void main(String[] args) throws IOException {
		JFrame frame = new MakeMapFrame();
		frame.setVisible(true);
	}
}
